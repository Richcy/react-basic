import './styles.css';

function Sidebar() {
  return(
    <h1 className="sidebar-wrapper ">Ini Sidebar</h1>
  );
}

export default Sidebar;